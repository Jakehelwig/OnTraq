﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConsoleApp1
{
    public partial class TeamDashboard : Form
    {
        public TeamDashboard()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TaskView f = new TaskView();
            f.Show();
            Close();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //needs juice
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Close();
        {
}
    }
    }
}
