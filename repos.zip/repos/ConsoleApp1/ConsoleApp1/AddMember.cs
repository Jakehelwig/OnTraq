﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConsoleApp1
{
    public partial class AddMember : Form
    {
        private String Username;
        public AddMember()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Username= textBox1.Text;
            if (isValid(Username)){

            }
            else
            {
                Error f = new Error();
                f.Show();
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
        public static Boolean isValid(String a)
        {
            //juice me 
            return true;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
        Close();
    }
    }
}
