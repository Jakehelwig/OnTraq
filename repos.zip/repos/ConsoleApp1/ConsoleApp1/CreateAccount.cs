﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConsoleApp1
{
    public partial class CreateAccount : Form
    {
        private String password = String.Empty;
        private String username = String.Empty;
        private String passwordChecker = String.Empty;
        public CreateAccount()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            username = textBox1.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            password = textBox2.Text;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            passwordChecker = textBox3.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (vaildP(passwordChecker, password) && validUsername(username))
            {
                //needs Juice
            }
            else
            {
                Error f = new Error();
                f.Show();
                Close();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Login fn = new Login();
            this.Hide();
            fn.ShowDialog();
            this.Close();
        }
        private static Boolean vaildP(String a, String b)
        {
            if (a.Equals(b))
            {
                return true;
            }
            else return false;
        }
        private Boolean validUsername(String a)//check the database for username
        {
            return true;
        }

    }
}
